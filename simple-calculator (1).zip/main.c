/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main() {
	int choice;
	float num1,num2,result;
	printf ("====simple calculator=====\n");
	printf("1.Addition(+)\n");
	printf("2.subtraction(-)\n");
	printf("3.Multiply(*)\n");
	printf("4.division(/)\n");
	printf("Enter your choice (1-4):");
	scanf("%d",&choice);
	printf("Enter two numbers:");
	scanf("%f%f,&num1 ,num2");
	switch (choice) {
case1:
		result = num1 + num2 ;
		printf("Result=%.2F",result);
		break;
case2:
		result =num1 - num2;
		printf("result=%.2f",result);
		break;
case3:
		result= num1*num2;
		printf("result=%.2f",result);
		break;
case4:
		if (num2!=0)
			printf("result =%.2f,num1/num2");
		else
			printf("Error! division by zero is not possible.");
		break;
	default:
		printf("invalid choice!");
	}
	return 0;
}