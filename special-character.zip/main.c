 /******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    char ch ;
    printf("Enter a character:");
    scanf("%c",&ch);
    if((ch>='A'&& ch<'Z') ||(ch>='a'&& ch<'z'))
    printf("It is an alphabets.");
    else if(ch>='0'&& ch<='9')
    printf(" it is digit.");
    else
    printf("it is a special character.");
    return 0;
}